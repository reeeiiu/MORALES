<?php

include 'connection.php';

if (isset($_POST['register'])) {
    // Get user input
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Validate the name length
    if (strlen($name) < 5) {
        echo "<script>alert('Name must be at least 5 characters long.');</script>";
    } else {
        // Validate the password
        if (strlen($password) < 8 || !preg_match("/[a-zA-Z]/", $password) || !preg_match("/[0-9]/", $password)) {
            echo "<script>alert('Password must be at least 8 characters long and contain both letters and numbers.');</script>";
        } else {
            // Check if username already exists
            $checkStmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
            $checkStmt->bind_param("s", $username);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();

            // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    }

            if ($checkResult->num_rows > 0) {
                // Username already exists
                echo "<script>alert('Username already exists. Please choose a different username.');</script>";
            } else {
                // Hash the password (Password Security)
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Prepare the statement
                $statement = $conn->prepare("INSERT INTO user (name, username, password) VALUES (?, ?, ?)");
                $statement->bind_param("sss", $name, $username, $hashed_password);

                // Execute the statement
                $statement->execute();

                // Alert Message and Redirect
                if ($statement->affected_rows > 0) {
                    // Registration successful
                    echo "<script>alert('Registration successful!');</script>";
                    header('Location: login.php'); 
                    exit(); 
                } else {
                    // Registration failed
                    echo "<script>alert('Registration failed. Please try again.');</script>";
                }

                $statement->close();
            }

            $checkStmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>

    <!-- Bootstrap CSS and JS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="style1.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>

<body>
<center><div style="max-width: 100%; width: 500px; border: 1px brown solid; box-shadow: 1px 1px 3px 1px antiquewhite; border-radius: 10px; padding: 15px 15px; margin-top:5%;" id="form">
        <h1 class="text-center fw-bold mb-4">User Registeration Form</h1>
        <form action="register.php" method="POST">
            <!-- Floating Label for Name -->
            <div class="form-floating mb-4">
                <input type="text" class="form-control" id="floatingName" placeholder="name" name="name" required>
                <label for="floatingName">
                    <i class="bi bi-person-fill me-2"></i>
                    Full Name
                </label>
            </div>

            <!-- Floating Label for Email -->
            <div class="form-floating mb-4">
                <input type="text" class="form-control" id="floatingEmail" placeholder="email" name="email" required>
                <label for="floatingEmail">
                    <i class="bi bi-person-fill me-2"></i>
                    Email
                </label>
            </div>

            <!-- Floating Label for Username -->
            <div class="form-floating mb-4">
                <input type="text" class="form-control" id="floatingUsername" placeholder="Username" name="username" required>
                <label for="floatingUsername">
                    <i class="bi bi-person-fill me-2"></i>
                    Username
                </label>
            </div>
            <!-- Floating Label for Password -->
            <div class="form-floating mb-4">
                <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" required>
                <label for="floatingPassword">
                    <i class="bi bi-lock-fill me-2"></i>
                    Password
                </label>
            </div>
            <div>
            <button style="border-radius:10px; padding:10px; background-color: purple; color:white; border: none; width: 100%;" name="register">Register</button>
            </div>
            <p style="text-align: left; margin-top:10px;">Password must be <b>8 character long</b>.</p>
            <p style="text-align: left;">Password must contain <b>both alphabet and numerical</b> characters.</p>
            <a href="login.php" style="color: saddlebrown;">
                 Go Back
            </a>
 
        </form></center>
    </div>
</body>

</html>