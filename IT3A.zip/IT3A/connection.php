<?php
// Database configuration
$host = "localhost"; // Replace with your database host, e.g., "127.0.0.1"
$username = "root";  // Replace with your database username
$password = "";      // Replace with your database password
$dbname = "notebook"; // Replace with your database name

// Create a connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optionally, set character set to UTF-8 (recommended)
$conn->set_charset("utf8");

// Uncomment for debugging connection
// echo "Connected successfully";
?>