<?php

include 'connection.php';

// Enable error reporting for debugging (optional during development)
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['login'])) {
    // Get user input
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Prepare the SQL statement with placeholders
    $stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $row['password'])) {
            // Successful Login
            session_start();

            // Store user ID in the session
            $_SESSION['user_id'] = $row['id'];

            // Redirect to index.php
            header("Location: index.html");
            exit(); // Ensure the script terminates after the redirect
        } else {
            // Incorrect Password
            echo "<script>alert('Incorrect Password. Please try again.');</script>";
        }
    } else {
        // Username not found
        echo "<script>alert('Username not found. Please try again.');</script>";
    }

    $stmt->close();
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="style1.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container border p-4 text-center" id="form" style="max-width: 100%; width: 400px; border: 1px brown solid; box-shadow: 1px 1px 3px 1px antiquewhite; border-radius: 10px; padding: 15px 15px; margin-top:5%;">
        <h1 class="text-center fw-bold mb-4">User Login</h1>
        <form action="login.php" method="POST">
            <div class="form-floating mb-4">
                <input type="text" class="form-control" id="floatingUsername" placeholder="Username" name="username" required>
                <label for="floatingUsername">
                    <i class="bi bi-person-fill me-2"></i>
                    Username
                </label>
            </div>
            <div class="form-floating mb-4">
                <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" required>
                <label for="floatingPassword">
                    <i class="bi bi-lock-fill me-2"></i>
                    Password
                </label>
            </div>
            <div>
            <button  style="border-radius:10px; padding:10px; background-color: purple; color:white; 
            border: none; width: 100%;" name="login">Login</button>
            </div>
            <br><a href="register.php" style="color: saddlebrown;">
                 Don't Have an account Yet? 
            </a>
        </form>
    </div>
</body>

</html>